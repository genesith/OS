#include <list.h>

void invalid_list_insert(struct list * target_list, int sector_num);

struct invalid_struct{
	int vpage_index;
	int sector;
	struct list_elem invalid_elem;
}




